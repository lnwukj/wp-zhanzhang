<?php

/**
 * 子主题函数
 * RiPro是一个优秀的主题，首页拖拽布局，高级筛选，自带会员生态系统，超全支付接口，你喜欢的样子我都有！
 * 正版唯一购买地址，全自动授权下载使用：https://vip.ylit.cc/
 * 作者唯一QQ：200933220 （油条）
 * 承蒙您对本主题的喜爱，我们愿向小三一样，做大哥的女人，做大哥网站中最想日的一个。
 * 能理解使用盗版的人，但是不能接受传播盗版，本身主题没几个钱，主题自有支付体系和会员体系，盗版风险太高，鬼知道那些人乱动什么代码，无利不起早。
 * 开发者不易，感谢支持，更好的更用心的等你来调教
 */

//加载style.css 子主题样式
function ripro_chlid_style() {
    if (!is_admin()) {
    	//挂在父主题优先最前
        wp_register_style('ripro_chlid_style', get_stylesheet_directory_uri() . '/diy.css',  array('app'), '', 'all');
        wp_enqueue_style('ripro_chlid_style');
    }
}
add_action('init', 'ripro_chlid_style');

require_once get_stylesheet_directory() . '/inc/codestar-framework/options/srcdict-theme.php';
// 加载简码
require_once get_stylesheet_directory() . '/inc/shortcodes/shortcodes.php';
require_once get_stylesheet_directory() . '/inc/shortcodes/shortcodespanel.php';