<div class="srcdict-footer">
    <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-3 widget--about">
            <div class="widget--content">
                <!--
                <div class="footer--logo mb-20">
                    <img class="tap-logo" src="<?php echo esc_url( _cao( 'site_footer_logo') ); ?>" data-dark="<?php echo esc_url(_cao( 'site_footer_logo')); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                </div>
                -->
                <h2 class="title"><?php echo _cao('footer_black_txt');?></h2>
                <p class="mb-10"><?php echo _cao('footer_black_desc');?></p>
            </div>
        </div>
        <!-- .col-md-2 end -->
        <div class="col-xs-12 col-sm-3 col-md-2src col-md-offset-1 widget--links">
            <div class="widget--title">
                <h5><?php echo _cao('footer_black_link1');?></h5>
            </div>
            <div class="widget--content">
                <ul class="list-unstyled mb-0">
                    <?php $footer_black_link1_group = _cao('footer_black_link1_group');
                    if (!empty($footer_black_link1_group)) {
                        foreach ($footer_black_link1_group as $key => $link) {
                            $_blank = ($link['_blank']) ? ' target="_blank"' : '' ;
                            echo '<li><a'.$_blank.' href="'.$link['_link'].'">'.$link['_title'].'</a></li>';
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
        <!-- .col-md-2 end -->
        <div class="col-xs-12 col-sm-3 col-md-2src widget--links">
            <div class="widget--title">
                <h5><?php echo _cao('footer_black_link2');?></h5>
            </div>
            <div class="widget--content">
                <ul class="list-unstyled mb-0">
                    <?php $footer_black_link2_group = _cao('footer_black_link2_group');
                    if (!empty($footer_black_link2_group)) {
                        foreach ($footer_black_link2_group as $key => $link) {
                            $_blank = ($link['_blank']) ? ' target="_blank"' : '' ;
                            echo '<li><a'.$_blank.' href="'.$link['_link'].'">'.$link['_title'].'</a></li>';
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
        <!-- .col-md-2 end -->
        
        <div class="col-xs-12 col-sm-12 col-md-4src widget--newsletter">
            <div class="widget--title">
                <h5><?php echo _cao('footer_black_copdesc');?></h5>
            </div>
            <div class="widget--content">
                <form class="newsletter--form mb-30f" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
                    <input type="text" class="form-control" name="s" placeholder="关键词">
                    <button type="submit"><i class="fa fa-arrow-right"></i></button>
                </form>
            </div>
            <div class="payment">
            	<img class="icon icon-v6 icon-v6-stripe wordpress" src="//cdn.ziyuanfeng.com/wordpress.svg" title="WordPress" style="margin-left: 0;">
                <img class="icon icon-v6 icon-v6-stripe teng" src="//cdn.ziyuanfeng.com/teng.svg" title="腾讯云">
                <img class="icon icon-v6 icon-v6-stripe ali" src="//cdn.ziyuanfeng.com/ali.svg" title="阿里云">
				<img class="icon icon-v6 icon-v6-stripe qiniu" src="//cdn.ziyuanfeng.com/qiniu.svg" title="七牛云">
				<img class="icon icon-v6 icon-v6-stripe weixinpay" src="//cdn.ziyuanfeng.com/weixinpay.svg" title="微信支付">
				<img class="icon icon-v6 icon-v6-stripe alipay" src="//cdn.ziyuanfeng.com/alipay.svg" title="支付宝">
        	</div>
        </div>

    </div>
</div>
</footer>
<div class="site-footer-nav">
	<div class="footer-colors"></div>
		<div class="footer-colors colors-shadow"></div>
			<!--Friendship Links Start-->
			<div class="container" style="padding-left:0;">
			<div class="codesign-dw">
			<div class="col-xs-12 friend-links">
			<h6 class="codesign-fl-title">友情链接：</h6>
			<ul class="codesign-fl">
			<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
			</ul>
			</div>
			</div>
			</div>
			<!--Friendship Links End-->			
			<?php if ( _cao( 'srcdict_copyright_text', '' ) != '' ) : ?>
			  <div class="site-info">
			  	<div class="footer-shouquan"><?php echo _cao( 'dict_ui_footer_state', '' ); ?></div>
			    <?php echo _cao( 'srcdict_copyright_text', '' ); ?>
			    <?php if(_cao('cao_ipc_info')) : ?>
			    <a href="http://beian.miit.gov.cn" target="_blank" class="text"><?php echo _cao('cao_ipc_info')?><br></a>
			    <?php endif; ?>
			  </div>
			<?php endif; ?>
			
		</div>