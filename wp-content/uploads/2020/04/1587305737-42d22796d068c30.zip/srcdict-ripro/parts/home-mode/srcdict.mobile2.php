<?php
$dict_ui_mobile2_pz1 = _cao('dict_ui_mobile2_pz1');
$dict_ui_mobile2_pz2 = _cao('dict_ui_mobile2_pz2');
$dict_ui_mobile2_pz3 = _cao('dict_ui_mobile2_pz3');
$dict_ui_mobile2_pz4 = _cao('dict_ui_mobile2_pz4');
?>
<div class="<?php if (_cao('dict_ui_mobile2_background')) : ?>srcbjs<?php endif; ?> section">
	<div class="home-first">
		<div class="container hide_sm">
				<div class="col-1-4">
					<div class="hf-widget hf-widget-1 hf-widget-software">
						<h3 class="hf-widget-title">
							<i class="<?php echo $title = ($dict_ui_mobile2_pz1['mobile2_1_icon']); ?>"></i>
							<a href="<?php echo $title = ($dict_ui_mobile2_pz1['mobile2_1_href']); ?>" target="_blank"><?php echo $title = ($dict_ui_mobile2_pz1['mobile2_1_title']); ?></a>
							<span><?php echo $title = ($dict_ui_mobile2_pz1['mobile2_1_describe']); ?></span>
							<div class="pages">
								<i class="prev">
									<i class="ri-arrow-left-s-line"></i>
								</i>
								<i class="next">
									<i class="ri-arrow-right-s-line"></i>
								</i>
							</div>
						</h3>
						<div class="hf-widget-content">
							<div class="scroll-h">
								<ul>
									<?php foreach ($dict_ui_mobile2_pz1['dict_ui_mobile2_one'] as $key => $item) {
                                        echo '<li>';
                                        echo '<a href="'.esc_url( $item['_href'] ).'" '.( $item['_blank'] ? ' target="_blank"' : '' ).'>';
                                        echo '<i class="thumb" style="background-image:url('.esc_url( $item['_img'] ).')"></i>';
                                        echo '<span>'.$item['_title'].'</span>';
                                        echo '</a>';
                                        echo '</li>';
                                    } ?> 
								</ul>
								
								<ul class="holdon">
									<?php foreach ($dict_ui_mobile2_pz1['dict_ui_mobile2_two'] as $key => $item) {
                                        echo '<li>';
                                        echo '<a href="'.esc_url( $item['_href'] ).'" '.( $item['_blank'] ? ' target="_blank"' : '' ).'>';
                                        echo '<i class="thumb" style="background-image:url('.esc_url( $item['_img'] ).')"></i>';
                                        echo '<span>'.$item['_title'].'</span>';
                                        echo '</a>';
                                        echo '</li>';
                                    } ?> 
								</ul>
								
							</div>
						</div>
					</div>
				</div>
				<div class="col-1-4 sxweb">
					<div class="hf-widget hf-widget-2">
						<h3 class="hf-widget-title">
							<i class="<?php echo $title = ($dict_ui_mobile2_pz2['mobile2_2_icon']); ?>"></i>
							<a href="<?php echo $title = ($dict_ui_mobile2_pz2['mobile2_2_href']); ?>" target="_blank"><?php echo $title = ($dict_ui_mobile2_pz2['mobile2_2_title']); ?></a>
							<span><?php echo $title = ($dict_ui_mobile2_pz2['mobile2_2_describe']); ?></span></h3>
						<div class="hf-widget-content">
							<div class="no-scroll hf-tags">
								<?php foreach ($dict_ui_mobile2_pz2['dict_ui_mobile2_2'] as $key => $item) {
                                        echo '<a href="'.esc_url( $item['_href'] ).'" '.( $item['_blank'] ? ' target="_blank"' : '' ).'>';
                                        echo '<span>'.$item['_title'].'</span>';
                                        echo '</a>';
                                    } ?> 
							</div>
						</div>
					</div>
				</div>
				<div class="col-1-4 sxweb">
					<div class="hf-widget hf-widget-1 hf-widget-hot-cats">
						<h3 class="hf-widget-title">
							<i class="<?php echo $title = ($dict_ui_mobile2_pz3['mobile2_3_icon']); ?>"></i>
							<a href="<?php echo $title = ($dict_ui_mobile2_pz3['mobile2_3_href']); ?>" target="_blank"><?php echo $title = ($dict_ui_mobile2_pz3['mobile2_3_title']); ?></a>
							<span><?php echo $title = ($dict_ui_mobile2_pz3['mobile2_3_describe']); ?></span></h3>
						<div class="hf-widget-content">
							<div class="scroll-h">
								<ul>
									
									<?php foreach ($dict_ui_mobile2_pz3['dict_ui_mobile2_3'] as $key => $item) {
										echo '<li>';
                                        echo '<a href="'.esc_url( $item['_href'] ).'" '.( $item['_blank'] ? ' target="_blank"' : '' ).'>';
                                        echo '<i class="hhicon '.$item['_icon'].'"></i>';
                                        echo '<span>'.$item['_title'].'</span>';
                                        echo '</a></li>';
                                    } ?>
                                    
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-1-4 sxweb">
					<div class="hf-widget hf-widget-4">
						<h3 class="hf-widget-title">
							<i class="<?php echo $title = ($dict_ui_mobile2_pz4['mobile2_4_icon']); ?>"></i>
							<a href="<?php echo $title = ($dict_ui_mobile2_pz4['mobile2_4_href']); ?>" target="_blank"><?php echo $title = ($dict_ui_mobile2_pz4['mobile2_4_title']); ?></a>
							<span><?php echo $title = ($dict_ui_mobile2_pz4['mobile2_4_describe']); ?></span>
							<div class="pages">
								<i class="prev">
									<i class="ri-arrow-left-s-line"></i>
								</i>
								<i class="next">
									<i class="ri-arrow-right-s-line"></i>
								</i>
							</div>
						</h3>
						<div class="hf-widget-content">
							<div class="scroll-h">
								<ul>
									<?php foreach ($dict_ui_mobile2_pz4['dict_ui_mobile2_4'] as $key => $item) {
										echo '<li><h3>';
                                        echo '<a href="'.esc_url( $item['_href'] ).'" '.( $item['_blank'] ? ' target="_blank"' : '' ).'>';
                                        echo '<i class="fa fa-volume-up">&nbsp;</i>';
                                        echo '<span>'.$item['_title'].'</span>';
                                        echo '<em>'.$item['_new'].'</em></a>';
                                        echo '</h3></li>';
                                    } ?> 
								</ul>
								<ul class="holdon">
									<?php foreach ($dict_ui_mobile2_pz4['dict_ui_mobile2_4_1'] as $key => $item) {
										echo '<li><h3>';
                                        echo '<a href="'.esc_url( $item['_href'] ).'" '.( $item['_blank'] ? ' target="_blank"' : '' ).'>';
                                        echo '<i class="fa fa-volume-up">&nbsp;</i>';
                                        echo '<span>'.$item['_title'].'</span>';
                                        echo '<em>'.$item['_new'].'</em></a>';
                                        echo '</h3></li>';
                                    } ?> 
								</ul>
							</div>
						</div>
					</div>
				</div>
		</div>
	</div>
</div>