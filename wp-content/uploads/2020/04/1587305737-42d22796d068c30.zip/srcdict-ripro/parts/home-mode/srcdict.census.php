<?php
$count_posts = wp_count_posts();
$users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users");
ob_start(); ?>
<div class="<?php if (_cao('dict_ui_sensus_background')) : ?>srcbjs<?php endif; ?> section text-center pb-0" style="padding-top:20px; height:75px;">
  <div class="container">
    <div class="alert alert-modern alert-dark">
      <div class="alert-content">
        <span class="type_icont_2"><i class="fa fa-bell-o"></i> 博主统计</span>
        <span class="description-17codesign">
          <p>&nbsp;&nbsp;<i class="fa fa-list-alt"></i>&nbsp;资源总数：<?php echo $published_posts = $count_posts->publish;?>个&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <i class="fa fa-user"></i>&nbsp;注册用户：<?php echo $users; ?>位&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <?php // 查询meta
		  $user_vip = $wpdb->get_var($wpdb->prepare("SELECT COUNT(user_id) FROM $wpdb->usermeta WHERE meta_key=%s AND meta_value=%s", 'cao_user_type', 'vip'));
		  ?>          
          <i class="fa fa-user-plus"></i>&nbsp;<?php echo _cao('site_vip_name')?>会员总数：<?php echo $user_vip ? $user_vip : '0'; ?>位&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <i class="fa fa-refresh"></i>&nbsp;本周更新：<?php echo get_week_post_count(); ?>篇&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <i class="fa fa-spinner"></i>&nbsp;今日更新：<?php echo WeeklyUpdate();?>篇&nbsp;&nbsp;
          </p>
        </span>
      </div>
    </div>
  </div>
</div>