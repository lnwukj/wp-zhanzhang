<?php 
$cont_zmki = _cao('content_zmki_mk', 7);
echo '<div>';
echo '<div id="'.$cont_zmki.'" class="article-copyright">'._cao('post_copyright').'<br/><a href="'.get_bloginfo('url').'">'.get_bloginfo('name').'</a> &raquo; <a href="'.get_permalink().'">'.get_the_title().'</a>';

if (_cao('srcdict_baidu_tj')) :
	echo baidu_record(); 
endif;

echo '</div>';
?>


