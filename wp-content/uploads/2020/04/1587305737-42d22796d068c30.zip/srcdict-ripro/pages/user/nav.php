<div class="col-xs-12 col-sm-12 col-md-12">
        <div class="nav-user">
            
<a href="/user/?action=index" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="我的主页" data-original-title="我的主页"><i class="text-xl nice-icon iconfont iconhome1"></i></span>主页
</a>
<a href="/user/?action=vip" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="我的会员" data-original-title="我的会员"><i class="text-xl nice-icon iconfont iconvip"></i></span>会员
</a>
<a href="/user/?action=charge" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="充值中心" data-original-title="充值中心"><i class="text-xl nice-icon iconfont iconzhanghuyue"></i></span>充值
</a>
<a href="/user/?action=mypay" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="已购资源" data-original-title="已购资源"><i class="text-xl nice-icon iconfont iconxiazai4"></i></span>已购
</a>
<a href="/user/?action=myfav" class="nav-user-link active">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="我的收藏" data-original-title="我的收藏"><i class="text-xl nice-icon iconfont iconvip-fav"></i></span>收藏
</a>        
<a href="/user/?action=mypost" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="我的资源" data-original-title="我的文章"><i class="text-xl nice-icon iconfont iconwenzhang1"></i></span>资源
</a>
<a href="/user/?action=write" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="发布资源" data-original-title="发布资源"><i class="text-xl nice-icon iconfont iconedit"></i></span>发布
</a>
<a href="/user/?action=ref" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="推广佣金" data-original-title="推广佣金"><i class="text-xl nice-icon iconfont icontuiguangdingdan"></i></span>推广
</a>
<a href="/user/?action=password" class="nav-user-link ">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="修改密码" data-original-title="修改密码"><i class="text-xl nice-icon iconfont iconsuo"></i></span>改密
</a>
<a href="<?php echo wp_logout_url(home_url()); ?>" class="nav-user-link active">
    <span class="d-block" data-toggle="tooltip" data-placement="bottom" title="退出登录" data-original-title="退出登录"><i class="text-xl nice-icon iconfont iconzhuxiaoxitong"></i></span>退出
</a>
</div>
</div>