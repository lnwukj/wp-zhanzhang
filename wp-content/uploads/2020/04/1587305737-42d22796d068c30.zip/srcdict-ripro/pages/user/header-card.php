<?php 
global $current_user;
$CaoUser = new CaoUser($current_user->ID);
$Reflog = new Reflog($current_user->ID);
$vip_status = $CaoUser->vip_status();
$cao_vip_downum = $CaoUser->cao_vip_downum($current_user->ID,$vip_status);
$_c = false;
if (is_boosvip_status($current_user->ID) && _cao('is_boosvip_down_num')) {
    $_c = true;
}elseif ($vip_status && !is_boosvip_status($current_user->ID) && _cao('is_vip_down_num')) {
    $_c = true;
}elseif(!$vip_status && _cao('is_novip_down_num')) {
    $_c = true;
}

?>

<link rel='stylesheet' href='//at.alicdn.com/t/font_1669795_3fl36jnpy23.css' type='text/css' />
<div class="card-box">
    <div class="row">
        <div class="col-md-4 col-sm-4">
            <div class="author-info mcolorbg4">
                <small><?php echo _cao('site_money_ua');?></small>
				<i class="dic iconticket"></i>
                <h3><?php echo $CaoUser->get_balance();?></h3>
                <p>当前余额</p>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
            <div class="author-info pcolorbg">
                <small><?php echo _cao('site_money_ua');?></small>
              	<i class="dic iconShoppingcart yue"></i>
                <h3><?php echo $CaoUser->get_consumed_balance();?></h3>
                <p>已消费</p>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
            <div class="author-info scolorbg">
                <small>RMB</small>
              	<i class="dic iconrmb"></i>
                <h3><?php echo $Reflog->get_yi_bonus();?></h3>
                <p>佣金</p>
            </div>
        </div>
        <?php if($_c): ?>
        <div class="col-md-4 col-sm-4">
            <div class="author-info mcolorbg2">
                <small>可下载</small>
                <i class="dic iconxiazai"></i>
                <h3><?php echo $cao_vip_downum['today_count_num'];?></h3>
                <p>今日/次</p>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
            <div class="author-info pcolorbg2">
                <small>已下载</small>
                <i class="dic iconxiazai2"></i>
                <h3><?php echo $cao_vip_downum['today_down_num'];?></h3>
                <p>今日/次</p>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
            <div class="author-info scolorbg2">
                <small>剩余下载</small>
                <i class="dic iconxiazai1"></i>
                <h3><?php echo $cao_vip_downum['over_down_num'];?></h3>
                <p>今日/次</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>