<?php
/*
Template Name: vip介绍
*/
$home_mode_vip = _cao('home_vip_mod');
?>
<?php get_header(); ?>

<div class="vip-banner">
  <div class="vipbj">
    <h2><?php echo $home_mode_vip['title'];?></h2>
    <p><?php echo $home_mode_vip['desc'];?></p>
	<?php if (is_user_logged_in()) : ?>
	<a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn-sm primary">前往开通</a>
	<?php else: ?>
	<a class="login-btn btn-sm primary">登录开通</a>
	<?php endif; ?>
    </div>
</div>
<div class="module-line"> <span class="arrow left-arrow"></span> <span class="text">会员尊享6项特权</span> <span class="arrow right-arrow"></span> </div>
<ul class="vip-slogan">
  <li class="vip-slogan-box"><i class="fa fa-pie-chart"></i>
    <div class="vip-slogan-text">
      <p>1000+资源，无限量下载</p>
      <p>真正的海量，无套路，诚意满满</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-jsfiddle " style="font-size: 60px"></i>
    <div class="vip-slogan-text">
      <p>5m/s速度，百度云极速下载</p>
      <p>本地无需备份，即需即下，无需等待</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-gratipay" style="font-size: 55px"></i>
    <div class="vip-slogan-text">
      <p>看上喜欢的，加入收藏</p>
      <p>文件夹式收藏，方便快捷，精确查到</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-vine"></i>
    <div class="vip-slogan-text">
      <p>50+原创精品，专享下载</p>
      <p>严格审核原创版权作品，VIP任性下载！</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-weixin"></i>
    <div class="vip-slogan-text">
      <p>全体在线客服，技术支持</p>
      <p>尊贵特权，极速响应，为你提供保障！</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-vimeo-square"></i>
    <div class="vip-slogan-text">
      <p>VIP标示，彰显尊贵身份</p>
      <p>点亮尊贵身份标示，散发与众不同气质</p>
    </div>
  </li>
</ul>
<div class="container">
  <article class="single-content">
    <div class="module-line"> <span class="arrow left-arrow"></span> <span class="text">VIP会员资费介绍</span> <span class="arrow right-arrow"></span>
      <div class="vip-desc">在这里，会员每月平均10个用户开通会员， 下载资源 300+份~</div>
    </div>

    <div class="container">
      <div class="vip-row vip-block-wrapper" style="padding-bottom: 0; padding-top: 30px; margin-bottom: 0; "> 
        <!--  -->
        <?php foreach ( $home_mode_vip['vip_group'] as $item ) : ?>
        <div class="vip-block-item">
          <div class="home-vipbox" >
            <div class="srcvip"> <img src="//img.srcdict.com/vip.png"> </div>
            <h3 class="content0-title"><?php echo $item['_time'];?></h3>
            <p class="vip-home-price"><i>￥</i><?php echo $item['_price'];?></p>
			<p><?php echo $item['_desc'];?></p>
			<?php if (is_user_logged_in()) : ?>
			<a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn-sm primary" style="background:<?php echo $item['_color'];?>"><p class="vip-bt">前往开通</p></a>
			<?php else: ?>
			<a class="login-btn btn-sm primary" style="background:<?php echo $item['_color'];?>"><p class="vip-bt">登录购买</p></a>
			<?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </article>
</div>
<div style="clear:both"></div>
<style type="text/css">
.site-content{ padding:0px;}
.term-bar{ display:none;}
</style>

<?php get_footer(); ?>
